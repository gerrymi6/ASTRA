"""
Setup script for Threat Modeler CLI.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

setup(
    name="threat-modeler",
    version="1.0.0",
    author="Threat Modeler Team",
    author_email="",
    description="CLI tool for automated threat modeling from Confluence documentation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/threat-modeler",
    packages=find_packages(where="."),
    package_dir={"": "."},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security",
        "Topic :: Utilities",
    ],
    python_requires=">=3.8",
    install_requires=[
        "openai>=1.0.0",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0",
        "click>=8.1.7",
        "rich>=13.7.0",
        "PyYAML>=6.0.1",
        "atlassian-python-api>=3.41.0",
        "markdown>=3.5.1",
        "beautifulsoup4>=4.12.2",
        "Pillow>=10.1.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "threat-modeler=threat_modeler.src.main:cli",
        ],
    },
    include_package_data=True,
    package_data={
        "threat_modeler": [
            "*.yaml",
            "*.txt",
            "src/**/*.py"
        ],
    },
    keywords="threat-modeling security confluence cli automation",
    project_urls={
        "Bug Reports": "https://github.com/your-org/threat-modeler/issues",
        "Source": "https://github.com/your-org/threat-modeler",
        "Documentation": "https://threat-modeler.readthedocs.io/",
    },
)
