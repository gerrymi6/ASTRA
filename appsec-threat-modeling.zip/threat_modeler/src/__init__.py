"""Threat Modeler CLI - Automated threat modeling from Confluence documentation."""
