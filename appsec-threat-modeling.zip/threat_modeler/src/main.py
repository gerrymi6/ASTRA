#!/usr/bin/env python3
"""
Threat Modeler CLI - Main entry point for the application.
"""

import sys
import os
from pathlib import Path
import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

# Add src directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from .core.threat_modeler import ThreatModeler
from .core.config import Config
from .utils.logger import setup_logger

console = Console()

@click.group()
@click.version_option(version="1.0.0")
def cli():
    """Threat Modeler CLI - Automated threat modeling from Confluence documentation."""
    pass

@cli.command()
@click.option('--confluence-url', required=True, help='Confluence page URL to fetch documentation from')
@click.option('--confluence-username', help='Confluence username (can also be set via CONFLUENCE_USERNAME env var)')
@click.option('--confluence-token', help='Confluence API token (can also be set via CONFLUENCE_TOKEN env var)')
@click.option('--llm-provider', default='openai', help='LLM provider to use (default: openai, options: openai, anthropic)')
@click.option('--llm-model', default='gpt-4', help='LLM model to use (default: gpt-4, for Anthropic use: claude-3-5-sonnet-20241022, claude-3-opus-20240229, etc.)')
@click.option('--openai-api-key', help='OpenAI API key (can also be set via OPENAI_API_KEY env var)')
@click.option('--anthropic-api-key', help='Anthropic API key (can also be set via ANTHROPIC_API_KEY env var)')
@click.option('--azure-api-key', help='Azure OpenAI API key (can also be set via AZURE_OPENAI_API_KEY env var)')
@click.option('--azure-base-url', help='Azure OpenAI base URL (e.g., https://your-resource.openai.azure.com/)')
@click.option('--azure-deployment', help='Azure OpenAI deployment name')
@click.option('--azure-api-version', help='Azure OpenAI API version (default: 2024-12-01-preview)')
@click.option('--azure-auth-method', help='Azure authentication method: api_key, aad, managed_identity (default: api_key)')
@click.option('--output-dir', default='./output', help='Output directory for generated threat models')
@click.option('--max-iterations', default=10, type=int, help='Maximum iterations for gap analysis (default: 10)')
@click.option('--generate-diagram', is_flag=True, help='Generate DFDv3 diagram in drawio format with iterative gap analysis (5 iterations max)')
@click.option('--verbose', is_flag=True, help='Enable verbose logging')
def run(confluence_url, confluence_username, confluence_token, llm_provider, llm_model,
        openai_api_key, anthropic_api_key, azure_api_key, azure_base_url, azure_deployment, azure_api_version, azure_auth_method, output_dir, max_iterations, generate_diagram, verbose):
    """Run threat modeling assessment on Confluence documentation."""

    # Setup logging
    logger = setup_logger(verbose=verbose)

    # Display welcome message
    welcome_text = Text("Threat Modeler CLI", style="bold blue")
    panel = Panel.fit(
        "[bold green]Starting threat modeling assessment...[/bold green]\n\n"
        f"Confluence URL: {confluence_url}\n"
        f"LLM Provider: {llm_provider}\n"
        f"Output Directory: {output_dir}",
        title=welcome_text,
        border_style="blue"
    )
    console.print(panel)

    try:
        # Load configuration
        config = Config(
            confluence_username=confluence_username,
            confluence_token=confluence_token,
            llm_provider=llm_provider,
            llm_model=llm_model,
            openai_api_key=openai_api_key,
            anthropic_api_key=anthropic_api_key,
            azure_api_key=azure_api_key,
            azure_base_url=azure_base_url,
            azure_deployment=azure_deployment,
            azure_api_version=azure_api_version,
            azure_auth_method=azure_auth_method,
            output_dir=output_dir,
            max_iterations=max_iterations,
            generate_diagram=generate_diagram
        )

        # Initialize threat modeler
        modeler = ThreatModeler(config, logger)

        # Run the threat modeling process
        result = modeler.run_threat_modeling(confluence_url)

        if result:
            console.print("\n[bold green]✓ Threat modeling assessment completed successfully![/bold green]")
            console.print(f"[dim]Output saved to: {result}[/dim]")
        else:
            console.print("\n[bold red]✗ Threat modeling assessment failed![/bold red]")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Error during threat modeling: {str(e)}")
        console.print(f"\n[bold red]Error:[/bold red] {str(e)}")
        sys.exit(1)

@cli.command()
def init():
    """Initialize configuration files and directories."""
    console.print("[bold blue]Initializing Threat Modeler...[/bold blue]")

    # Create necessary directories
    dirs_to_create = [
        Path('./configs'),
        Path('./prompts'),
        Path('./output')
    ]

    for directory in dirs_to_create:
        directory.mkdir(exist_ok=True)
        console.print(f"[green]✓[/green] Created directory: {directory}")

    # Copy template files from package
    import threat_modeler

    template_files = [
        (Path('./configs/default.yaml'), Path(threat_modeler.__file__).parent / 'configs' / 'default.yaml'),
        (Path('./prompts/threat_model_generation.txt'), Path(threat_modeler.__file__).parent / 'prompts' / 'threat_model_generation.txt'),
        (Path('./prompts/gap_analysis.txt'), Path(threat_modeler.__file__).parent / 'prompts' / 'gap_analysis.txt')
    ]

    for dest_path, src_path in template_files:
        if not dest_path.exists() and src_path.exists():
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_text(src_path.read_text())
            console.print(f"[green]✓[/green] Created file: {dest_path}")
        elif dest_path.exists():
            console.print(f"[yellow]⚠[/yellow] File already exists: {dest_path}")
        else:
            console.print(f"[red]✗[/red] Template file not found: {src_path}")

    console.print("\n[bold green]Initialization complete![/bold green]")
    console.print("You can now run: threat-modeler run --help")

if __name__ == '__main__':
    cli()
