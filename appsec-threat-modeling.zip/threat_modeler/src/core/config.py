"""
Configuration management for Threat Modeler.
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional
import yaml
from dataclasses import dataclass, field

@dataclass
class LLMConfig:
    """Configuration for LLM provider."""
    provider: str = "openai"
    model: str = "gpt-4"
    temperature: float = 0.7
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    azure_deployment: Optional[str] = None
    azure_api_version: Optional[str] = None
    azure_auth_method: str = "api_key"  # api_key, aad, managed_identity

@dataclass
class ConfluenceConfig:
    """Configuration for Confluence integration."""
    username: Optional[str] = None
    token: Optional[str] = None
    timeout: int = 30
    max_retries: int = 3
    verify_ssl: bool = True

@dataclass
class OutputConfig:
    """Configuration for output generation."""
    directory: str = "./output"
    format: str = "markdown"
    include_images: bool = True
    create_timestamped_dirs: bool = True

@dataclass
class ThreatModelingConfig:
    """Configuration for threat modeling process."""
    max_iterations: int = 10
    gap_analysis_enabled: bool = True
    generate_diagram: bool = False
    prompt_files: Dict[str, str] = field(default_factory=lambda: {
        "threat_model_generation": "./prompts/threat_model_generation.txt",
        "gap_analysis": "./prompts/gap_analysis.txt"
    })

@dataclass
class Config:
    """Main configuration class for Threat Modeler."""

    # Core configurations
    llm: LLMConfig = field(default_factory=LLMConfig)
    confluence: ConfluenceConfig = field(default_factory=ConfluenceConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    threat_modeling: ThreatModelingConfig = field(default_factory=ThreatModelingConfig)

    def __init__(
        self,
        confluence_username: Optional[str] = None,
        confluence_token: Optional[str] = None,
        llm_provider: str = "openai",
        llm_model: str = "gpt-4",
        openai_api_key: Optional[str] = None,
        anthropic_api_key: Optional[str] = None,
        azure_api_key: Optional[str] = None,
        azure_base_url: Optional[str] = None,
        azure_deployment: Optional[str] = None,
        azure_api_version: Optional[str] = None,
        azure_auth_method: str = "api_key",
        output_dir: str = "./output",
        max_iterations: int = 10,
        generate_diagram: bool = False,
        config_file: Optional[str] = None
    ):
        """Initialize configuration with CLI parameters and config file."""

        # Initialize dataclass fields first
        self.llm = LLMConfig()
        self.confluence = ConfluenceConfig()
        self.output = OutputConfig()
        self.threat_modeling = ThreatModelingConfig()

        # Load from config file if provided
        if config_file and Path(config_file).exists():
            self._load_from_file(config_file)

        # Override with CLI parameters
        self.llm.provider = llm_provider
        self.llm.model = llm_model
        self.output.directory = output_dir
        self.threat_modeling.max_iterations = max_iterations
        self.threat_modeling.generate_diagram = generate_diagram

        # Set credentials from CLI or environment
        if confluence_username:
            self.confluence.username = confluence_username
        elif os.getenv('CONFLUENCE_USERNAME'):
            self.confluence.username = os.getenv('CONFLUENCE_USERNAME')

        if confluence_token:
            self.confluence.token = confluence_token
        elif os.getenv('CONFLUENCE_TOKEN'):
            self.confluence.token = os.getenv('CONFLUENCE_TOKEN')

        if openai_api_key:
            self.llm.api_key = openai_api_key
        elif os.getenv('OPENAI_API_KEY'):
            self.llm.api_key = os.getenv('OPENAI_API_KEY')

        # Handle Anthropic API key
        if anthropic_api_key:
            self.llm.api_key = anthropic_api_key
        elif os.getenv('ANTHROPIC_API_KEY'):
            self.llm.api_key = os.getenv('ANTHROPIC_API_KEY')

        # Handle Azure OpenAI configuration
        if azure_api_key:
            self.llm.api_key = azure_api_key
        elif os.getenv('AZURE_OPENAI_API_KEY'):
            self.llm.api_key = os.getenv('AZURE_OPENAI_API_KEY')

        # Handle base URL - prioritize provider-specific env vars
        if self.llm.provider == "anthropic":
            # For Anthropic, check ANTHROPIC_BASE_URL first, then azure_base_url, then AZURE_OPENAI_BASE_URL
            if os.getenv('ANTHROPIC_BASE_URL'):
                self.llm.base_url = os.getenv('ANTHROPIC_BASE_URL')
            elif azure_base_url:
                self.llm.base_url = azure_base_url
            elif os.getenv('AZURE_OPENAI_BASE_URL'):
                self.llm.base_url = os.getenv('AZURE_OPENAI_BASE_URL')
        else:
            # For OpenAI, use azure_base_url or AZURE_OPENAI_BASE_URL
            if azure_base_url:
                self.llm.base_url = azure_base_url
            elif os.getenv('AZURE_OPENAI_BASE_URL'):
                self.llm.base_url = os.getenv('AZURE_OPENAI_BASE_URL')

        if azure_deployment:
            self.llm.azure_deployment = azure_deployment
        elif os.getenv('AZURE_OPENAI_DEPLOYMENT'):
            self.llm.azure_deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT')

        if azure_api_version:
            self.llm.azure_api_version = azure_api_version
        elif os.getenv('AZURE_OPENAI_API_VERSION'):
            self.llm.azure_api_version = os.getenv('AZURE_OPENAI_API_VERSION')

        # Set Azure authentication method
        if azure_auth_method:
            self.llm.azure_auth_method = azure_auth_method
        elif os.getenv('AZURE_OPENAI_AUTH_METHOD'):
            self.llm.azure_auth_method = os.getenv('AZURE_OPENAI_AUTH_METHOD')

        # Validate configuration
        self._validate()

    def _load_from_file(self, config_file: str) -> None:
        """Load configuration from YAML file."""
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)

            if not data:
                return

            # Load LLM config
            if 'llm' in data:
                llm_data = data['llm']
                self.llm.provider = llm_data.get('provider', self.llm.provider)
                self.llm.model = llm_data.get('model', self.llm.model)
                self.llm.temperature = llm_data.get('temperature', self.llm.temperature)

            # Load Confluence config
            if 'confluence' in data:
                conf_data = data['confluence']
                self.confluence.timeout = conf_data.get('timeout', self.confluence.timeout)
                self.confluence.max_retries = conf_data.get('max_retries', self.confluence.max_retries)

            # Load output config
            if 'output' in data:
                out_data = data['output']
                self.output.format = out_data.get('format', self.output.format)
                self.output.include_images = out_data.get('include_images', self.output.include_images)

            # Load threat modeling config
            if 'threat_modeling' in data:
                tm_data = data['threat_modeling']
                self.threat_modeling.max_iterations = tm_data.get('max_iterations', self.threat_modeling.max_iterations)
                self.threat_modeling.gap_analysis_enabled = tm_data.get('gap_analysis_enabled', self.threat_modeling.gap_analysis_enabled)

        except Exception as e:
            raise ValueError(f"Error loading configuration file {config_file}: {str(e)}")

    def _validate(self) -> None:
        """Validate configuration settings."""
        # Validate API key for both OpenAI and Azure OpenAI
        if self.llm.provider == "openai":
            # For Azure OpenAI with AAD or Managed Identity, API key is not required
            if self.llm.base_url and self.llm.azure_auth_method in ["aad", "managed_identity"]:
                # AAD and Managed Identity don't require API keys
                pass
            elif not self.llm.api_key:
                raise ValueError("API key is required when using OpenAI provider. Set via --openai-api-key, --azure-api-key, or environment variables (OPENAI_API_KEY, AZURE_OPENAI_API_KEY).")

            # If base_url is set, validate Azure-specific requirements
            if self.llm.base_url:
                if not self.llm.base_url.startswith(('http://', 'https://')):
                    raise ValueError("Azure base URL must be a valid HTTP/HTTPS URL.")
                if not self.llm.azure_deployment and self.llm.model == "gpt-4":
                    raise ValueError("Azure deployment name is recommended when using Azure OpenAI. Set via --azure-deployment or AZURE_OPENAI_DEPLOYMENT environment variable.")

                # Validate Azure authentication method
                valid_auth_methods = ["api_key", "aad", "managed_identity"]
                if self.llm.azure_auth_method not in valid_auth_methods:
                    raise ValueError(f"Invalid Azure authentication method: {self.llm.azure_auth_method}. Valid options are: {', '.join(valid_auth_methods)}")
        elif self.llm.provider == "anthropic":
            if not self.llm.api_key:
                raise ValueError("API key is required when using Anthropic provider. Set via --anthropic-api-key or environment variable (ANTHROPIC_API_KEY).")

        if not self.confluence.username or not self.confluence.token:
            raise ValueError("Confluence username and token are required. Set via --confluence-username/--confluence-token or environment variables.")

        if self.threat_modeling.max_iterations < 1 or self.threat_modeling.max_iterations > 20:
            raise ValueError("Max iterations must be between 1 and 20.")

        # Validate output directory
        output_path = Path(self.output.directory)
        if not output_path.exists():
            output_path.mkdir(parents=True, exist_ok=True)

        # Validate prompt files exist
        for prompt_name, prompt_file in self.threat_modeling.prompt_files.items():
            if not Path(prompt_file).exists():
                raise ValueError(f"Prompt file not found: {prompt_file}")

    def load_prompt(self, prompt_name: str) -> str:
        """Load prompt content from file."""
        prompt_file = self.threat_modeling.prompt_files.get(prompt_name)
        if not prompt_file:
            raise ValueError(f"Unknown prompt: {prompt_name}")

        prompt_path = Path(prompt_file)
        if not prompt_path.exists():
            raise ValueError(f"Prompt file not found: {prompt_file}")

        with open(prompt_path, 'r', encoding='utf-8') as f:
            return f.read().strip()
