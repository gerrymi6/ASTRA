"""
LLM client for interacting with various language model providers.
"""

import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import logging

try:
    from openai import OpenAI, AzureOpenAI
except ImportError:
    OpenAI = None
    AzureOpenAI = None

try:
    from anthropic import Anthropic
    try:
        from anthropic import AnthropicFoundry
    except ImportError:
        AnthropicFoundry = None
except ImportError:
    Anthropic = None
    AnthropicFoundry = None

@dataclass
class LLMResponse:
    """Response from LLM API."""
    content: str
    model: str
    usage: Dict[str, Any] = None
    finish_reason: str = ""

    def __post_init__(self):
        if self.usage is None:
            self.usage = {}

class LLMClient:
    """Client for interacting with LLM APIs."""

    def __init__(self, provider: str, model: str, api_key: str, logger: logging.Logger,
                 temperature: float = 0.7, base_url: Optional[str] = None, azure_deployment: Optional[str] = None,
                 azure_api_version: Optional[str] = None, azure_auth_method: str = "api_key"):
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self.logger = logger
        self.temperature = temperature
        self.base_url = base_url
        self.azure_deployment = azure_deployment
        self.azure_api_version = azure_api_version
        self.azure_auth_method = azure_auth_method

        # Initialize client based on provider
        if provider == "openai":
            if OpenAI is None:
                raise ImportError("openai package is required for OpenAI provider")

            # Check if this is Azure OpenAI (has base_url with azure configuration)
            if base_url and azure_deployment:
                # Azure OpenAI configuration - use AzureOpenAI client
                if AzureOpenAI is None:
                    raise ImportError("AzureOpenAI client is required for Azure OpenAI. Please install the latest openai package.")

                self.is_azure = True
                self.effective_model = azure_deployment  # Use deployment name as model

                # Configure authentication based on method
                if azure_auth_method == "aad":
                    # Azure Active Directory authentication
                    try:
                        from azure.identity import DefaultAzureCredential

                        credential = DefaultAzureCredential()
                        token = credential.get_token("https://cognitiveservices.azure.com/.default")

                        client_kwargs = {
                            "azure_endpoint": base_url,
                            "api_version": azure_api_version or "2024-12-01-preview",
                            "azure_ad_token_provider": lambda: credential.get_token("https://cognitiveservices.azure.com/.default").token
                        }
                        self.logger.info(f"Initialized Azure OpenAI client with AAD authentication: {base_url}")

                    except ImportError:
                        raise ImportError("azure-identity package is required for Azure AD authentication. Install with: pip install azure-identity")

                elif azure_auth_method == "managed_identity":
                    # Azure Managed Identity authentication
                    try:
                        from azure.identity import ManagedIdentityCredential

                        credential = ManagedIdentityCredential()
                        token = credential.get_token("https://cognitiveservices.azure.com/.default")

                        client_kwargs = {
                            "azure_endpoint": base_url,
                            "api_version": azure_api_version or "2024-12-01-preview",
                            "azure_ad_token_provider": lambda: credential.get_token("https://cognitiveservices.azure.com/.default").token
                        }
                        self.logger.info(f"Initialized Azure OpenAI client with Managed Identity authentication: {base_url}")

                    except ImportError:
                        raise ImportError("azure-identity package is required for Managed Identity authentication. Install with: pip install azure-identity")

                else:
                    # Default API Key authentication
                    client_kwargs = {
                        "azure_endpoint": base_url,
                        "api_version": azure_api_version or "2024-12-01-preview",
                        "api_key": api_key
                    }
                    self.logger.info(f"Initialized Azure OpenAI client with API Key authentication: {base_url}")

                self.client = AzureOpenAI(**client_kwargs)
            else:
                # Regular OpenAI configuration
                self.is_azure = False
                self.effective_model = model

                client_kwargs = {"api_key": api_key}
                if base_url:
                    client_kwargs["base_url"] = base_url

                self.client = OpenAI(**client_kwargs)
        elif provider == "anthropic":
            if Anthropic is None:
                raise ImportError("anthropic package is required for Anthropic provider. Install with: pip install anthropic")
            
            self.is_azure = False
            self.effective_model = model
            
            client_kwargs = {"api_key": api_key}
            
            # Check if this is Azure Foundry (has base_url)
            if base_url:
                # Use AnthropicFoundry for Azure Foundry endpoints
                if AnthropicFoundry is None:
                    raise ImportError("AnthropicFoundry is required for Azure Foundry. Please ensure you have the latest anthropic package installed.")
                
                # Normalize Azure Foundry base URL
                normalized_base_url = self._normalize_azure_foundry_url(base_url)
                client_kwargs["base_url"] = normalized_base_url
                self.client = AnthropicFoundry(**client_kwargs)
                self.is_azure_foundry = True
                self.logger.info(f"Initialized AnthropicFoundry client with base_url: {normalized_base_url}, model: {model}")
            else:
                # Use regular Anthropic client for standard API
                self.client = Anthropic(**client_kwargs)
                self.is_azure_foundry = False
                self.logger.info(f"Initialized Anthropic client with model {model}")
        else:
            raise ValueError(f"Unsupported LLM provider: {provider}")

    def generate_response(self, prompt: str, images: Optional[Dict[str, str]] = None,
                         max_tokens: int = 4000) -> LLMResponse:
        """Generate response from LLM with optional images."""

        self.logger.debug(f"Sending request to {self.provider} with model {self.model}")

        try:
            if self.provider == "openai":
                return self._call_openai(prompt, images, max_tokens)
            elif self.provider == "anthropic":
                return self._call_anthropic(prompt, images, max_tokens)
            else:
                raise ValueError(f"Unsupported provider: {self.provider}")

        except Exception as e:
            self.logger.error(f"LLM API call failed: {str(e)}")
            raise

    def _call_openai(self, prompt: str, images: Optional[Dict[str, str]] = None,
                    max_tokens: int = 4000) -> LLMResponse:
        """Call OpenAI API with text and optional images."""

        messages = [{"role": "user", "content": []}]

        # Add text content
        messages[0]["content"].append({
            "type": "text",
            "text": prompt
        })

        # Add images if provided
        if images:
            for filename, image_data in images.items():
                messages[0]["content"].append({
                    "type": "image_url",
                    "image_url": {
                        "url": image_data,
                        "detail": "high"
                    }
                })

        # Call API
        create_params = {
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": max_tokens,
            "top_p": 1,
            "frequency_penalty": 0,
            "presence_penalty": 0
        }

        # For Azure OpenAI, use deployment name as model (AzureOpenAI client requires this)
        if self.is_azure:
            create_params["model"] = self.effective_model

        response = self.client.chat.completions.create(**create_params)

        # Extract response
        choice = response.choices[0]
        content = choice.message.content

        # Extract usage information
        usage = {
            "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
            "completion_tokens": response.usage.completion_tokens if response.usage else 0,
            "total_tokens": response.usage.total_tokens if response.usage else 0
        }

        self.logger.debug(f"LLM response received. Tokens used: {usage['total_tokens']}")

        return LLMResponse(
            content=content,
            model=self.model,
            usage=usage,
            finish_reason=choice.finish_reason
        )

    def _call_anthropic(self, prompt: str, images: Optional[Dict[str, str]] = None,
                       max_tokens: int = 4000) -> LLMResponse:
        """Call Anthropic API with text and optional images."""
        
        content_blocks = []
        
        # Add text content
        content_blocks.append({
            "type": "text",
            "text": prompt
        })
        
        # Add images if provided
        if images:
            for filename, image_data in images.items():
                # Anthropic expects base64 encoded images
                # image_data should be in format: "data:image/png;base64,<base64_data>"
                if image_data.startswith("data:image"):
                    # Extract base64 data
                    header, base64_data = image_data.split(",", 1)
                    # Extract media type from header (e.g., "data:image/png;base64")
                    media_type = header.split(":")[1].split(";")[0]
                    
                    content_blocks.append({
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": base64_data
                        }
                    })
                else:
                    # If it's already base64 without data URI, assume PNG
                    content_blocks.append({
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": image_data
                        }
                    })
        
        # Anthropic messages format: list of message objects
        messages = [{
            "role": "user",
            "content": content_blocks
        }]
        
        # Call API
        create_params = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": self.temperature,
            "messages": messages
        }
        
        response = self.client.messages.create(**create_params)
        
        # Extract response
        # Anthropic returns content as a list of content blocks
        content_blocks = response.content
        content = ""
        for block in content_blocks:
            if block.type == "text":
                content += block.text
        
        # Extract usage information
        usage = {
            "input_tokens": response.usage.input_tokens if response.usage else 0,
            "output_tokens": response.usage.output_tokens if response.usage else 0,
            "prompt_tokens": response.usage.input_tokens if response.usage else 0,  # Alias for compatibility
            "completion_tokens": response.usage.output_tokens if response.usage else 0,  # Alias for compatibility
            "total_tokens": (response.usage.input_tokens + response.usage.output_tokens) if response.usage else 0
        }
        
        # Extract stop reason
        stop_reason = response.stop_reason if hasattr(response, 'stop_reason') else "stop"
        
        self.logger.debug(f"LLM response received. Tokens used: {usage['total_tokens']}")
        
        return LLMResponse(
            content=content,
            model=self.model,
            usage=usage,
            finish_reason=stop_reason
        )

    def _normalize_azure_foundry_url(self, base_url: str) -> str:
        """Normalize Azure Foundry base URL to ensure it has the correct format.
        
        Azure Foundry URLs should:
        - Use services.ai.azure.com domain (not cognitiveservices.azure.com)
        - End with /anthropic/
        """
        url = base_url.strip()
        
        # Fix domain if it's using the old cognitiveservices domain
        if 'cognitiveservices.azure.com' in url:
            url = url.replace('cognitiveservices.azure.com', 'services.ai.azure.com')
            self.logger.warning(f"Updated base_url domain from cognitiveservices.azure.com to services.ai.azure.com")
        
        # Remove trailing slash if present (we'll add /anthropic/ at the end)
        url = url.rstrip('/')
        
        # Ensure it ends with /anthropic/
        if not url.endswith('/anthropic'):
            url = f"{url}/anthropic"
        
        # Ensure final trailing slash
        url = f"{url}/"
        
        return url

    def validate_connection(self) -> bool:
        """Validate connection to LLM provider."""
        try:
            # Send a simple test request
            test_prompt = "Hello, please respond with 'OK' if you can understand this message."
            response = self.generate_response(test_prompt, max_tokens=10)

            if response.content and len(response.content.strip()) > 0:
                self.logger.info(f"✓ LLM connection validated with {self.provider}")
                return True
            else:
                self.logger.error("LLM returned empty response during validation")
                return False

        except Exception as e:
            self.logger.error(f"LLM connection validation failed: {str(e)}")
            return False
