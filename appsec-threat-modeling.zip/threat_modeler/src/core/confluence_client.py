"""
Confluence API client for fetching documentation and images.
"""

import re
import base64
import requests
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse, urljoin, unquote
from pathlib import Path
import logging
from dataclasses import dataclass
import xml.etree.ElementTree as ET
from html import unescape

from .config import ConfluenceConfig
from ..utils.image_converter import ImageConverter

@dataclass
class ConfluencePage:
    """Represents a Confluence page with content and images."""
    title: str
    content: str
    images: Dict[str, str] = None  # filename -> base64 content
    url: str = ""

    def __post_init__(self):
        if self.images is None:
            self.images = {}

class ConfluenceClient:
    """Client for interacting with Confluence API."""

    def __init__(self, config: ConfluenceConfig, logger: logging.Logger):
        self.config = config
        self.logger = logger
        self.session = requests.Session()
        self.image_converter = ImageConverter(logger)

        # Set up authentication
        if config.username and config.token:
            auth = (config.username, config.token)
            self.session.auth = auth

        # Configure session
        self.session.verify = config.verify_ssl
        self.session.timeout = config.timeout

        # Common headers
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })

    def extract_page_info(self, confluence_url: str) -> Tuple[str, str, str]:
        """Extract base URL, space key, and page ID from Confluence URL."""
        # Parse URL to extract components
        parsed = urlparse(confluence_url)

        # Extract base URL - include /wiki if present
        base_url = f"{parsed.scheme}://{parsed.netloc}"
        path_parts = parsed.path.strip('/').split('/')

        # Check if /wiki is present in the path
        if path_parts and path_parts[0] == 'wiki':
            base_url = f"{base_url}/wiki"
            self.logger.debug(f"Detected /wiki in URL, base_url: {base_url}")

        space_key = ""
        page_id = ""

        # Look for patterns like /spaces/SPACE/pages/PAGEID or /wiki/spaces/SPACE/pages/PAGEID
        if 'spaces' in path_parts and 'pages' in path_parts:
            spaces_index = path_parts.index('spaces')
            pages_index = path_parts.index('pages')

            if spaces_index + 1 < len(path_parts):
                space_key = path_parts[spaces_index + 1]
            if pages_index + 1 < len(path_parts):
                page_id = path_parts[pages_index + 1]

        # Alternative pattern: /display/SPACE/Page+Title (legacy URLs)
        elif 'display' in path_parts:
            display_index = path_parts.index('display')
            if display_index + 1 < len(path_parts):
                space_key = path_parts[display_index + 1]

        if not space_key or not page_id:
            raise ValueError(f"Could not extract space key and page ID from URL: {confluence_url}")

        return base_url, space_key, page_id

    def get_page_content(self, confluence_url: str) -> ConfluencePage:
        """Fetch page content and images from Confluence."""
        self.logger.info(f"Fetching Confluence page: {confluence_url}")

        base_url, space_key, page_id = self.extract_page_info(confluence_url)

        # Construct API URL
        api_url = f"{base_url}/rest/api/content/{page_id}"
        params = {
            'expand': 'body.storage,version,space'
        }

        self.logger.debug(f"Constructed API URL: {api_url}")

        try:
            response = self.session.get(api_url, params=params)
            response.raise_for_status()

            data = response.json()

            # Extract page information
            title = data.get('title', 'Unknown Title')
            content_html = data.get('body', {}).get('storage', {}).get('value', '')

            self.logger.info(f"Successfully fetched page: {title}")

            # Extract and parse drawio diagrams
            drawio_content = self._extract_and_parse_drawio_diagrams(content_html)
            
            # Convert HTML to markdown-like text (basic conversion)
            content_text = self._html_to_text(content_html)
            
            # Append drawio diagram information to content
            if drawio_content:
                content_text += "\n\n## Drawio Diagrams\n\n" + drawio_content

            # Create page object
            page = ConfluencePage(
                title=title,
                content=content_text,
                url=confluence_url
            )

            # Extract and fetch images from attachments
            page.images = self._fetch_page_attachments(base_url, page_id)

            return page

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Failed to fetch Confluence page: {str(e)}")
            raise

    def _html_to_text(self, html_content: str) -> str:
        """Convert HTML content to readable text."""
        # Basic HTML tag removal and cleanup
        # Remove script and style elements
        html_content = re.sub(r'<script[^>]*>.*?</script>', '', html_content, flags=re.DOTALL | re.IGNORECASE)
        html_content = re.sub(r'<style[^>]*>.*?</style>', '', html_content, flags=re.DOTALL | re.IGNORECASE)

        # Replace common HTML elements with markdown equivalents
        replacements = [
            (r'<h1[^>]*>(.*?)</h1>', r'# \1\n'),
            (r'<h2[^>]*>(.*?)</h2>', r'## \1\n'),
            (r'<h3[^>]*>(.*?)</h3>', r'### \1\n'),
            (r'<h4[^>]*>(.*?)</h4>', r'#### \1\n'),
            (r'<p[^>]*>(.*?)</p>', r'\1\n\n'),
            (r'<br[^>]*>', r'\n'),
            (r'<strong[^>]*>(.*?)</strong>', r'**\1**'),
            (r'<em[^>]*>(.*?)</em>', r'*\1*'),
            (r'<ul[^>]*>(.*?)</ul>', r'\1'),
            (r'<ol[^>]*>(.*?)</ol>', r'\1'),
            (r'<li[^>]*>(.*?)</li>', r'- \1\n'),
            (r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', r'[\2](\1)'),
            (r'<code[^>]*>(.*?)</code>', r'`\1`'),
            (r'<pre[^>]*>(.*?)</pre>', r'```\n\1\n```'),
            (r'<table[^>]*>(.*?)</table>', r'\1'),
            (r'<tr[^>]*>(.*?)</tr>', r'\1\n'),
            (r'<td[^>]*>(.*?)</td>', r'| \1 '),
            (r'<th[^>]*>(.*?)</th>', r'| **\1** '),
        ]

        text = html_content
        for pattern, replacement in replacements:
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE | re.DOTALL)

        # Clean up extra whitespace and empty lines
        text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
        text = re.sub(r'[ \t]+', ' ', text)

        return text.strip()

    def _extract_and_fetch_images(self, html_content: str, base_url: str) -> Dict[str, str]:
        """Extract image URLs from HTML and fetch their content."""
        images = {}

        # Find all image tags
        img_pattern = r'<img[^>]+src="([^"]+)"[^>]*>'
        matches = re.findall(img_pattern, html_content, re.IGNORECASE)

        self.logger.info(f"Found {len(matches)} images in the page")

        for i, img_url in enumerate(matches):
            try:
                # Convert relative URLs to absolute
                if not img_url.startswith('http'):
                    img_url = urljoin(base_url, img_url)

                # Generate filename
                filename = f"image_{i+1}.{self._get_image_extension(img_url)}"

                # Fetch image content
                image_data = self._fetch_image(img_url)
                if image_data:
                    images[filename] = image_data
                    self.logger.debug(f"Fetched image: {filename}")

            except Exception as e:
                self.logger.warning(f"Failed to fetch image {img_url}: {str(e)}")
                continue

        return images

    def _fetch_image(self, image_url: str) -> Optional[str]:
        """Fetch image content and return as base64 string with LLM-compatible format."""
        try:
            response = self.session.get(image_url, timeout=self.config.timeout)
            response.raise_for_status()

            # Get content type
            content_type = response.headers.get('content-type', 'image/png')
            
            # Use image converter to handle SVG conversion and optimization
            return self.image_converter.convert_to_base64_data_url(response.content, content_type)

        except requests.exceptions.RequestException as e:
            self.logger.warning(f"Failed to fetch image from {image_url}: {str(e)}")
            return None
        except Exception as e:
            self.logger.warning(f"Failed to process image from {image_url}: {str(e)}")
            return None

    def _fetch_page_attachments(self, base_url: str, page_id: str) -> Dict[str, str]:
        """Fetch image attachments from a Confluence page."""
        images = {}

        # Construct attachments API URL
        attachments_url = f"{base_url}/rest/api/content/{page_id}/child/attachment"

        try:
            self.logger.debug(f"Fetching attachments from: {attachments_url}")

            response = self.session.get(attachments_url)
            response.raise_for_status()

            attachments_data = response.json()
            attachments = attachments_data.get('results', [])

            self.logger.info(f"Found {len(attachments)} attachments for page {page_id}")

            # Filter for image files and download them
            image_extensions = {'jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp'}

            for attachment in attachments:
                filename = attachment.get('title', '')
                if not filename:
                    continue

                # Check if it's an image file
                file_extension = filename.split('.')[-1].lower() if '.' in filename else ''
                if file_extension in image_extensions:
                    # Get download link
                    download_url = f"{base_url}{attachment.get('_links', {}).get('download', '')}"

                    if download_url:
                        self.logger.debug(f"Downloading image: {filename}")
                        image_data = self._download_attachment(download_url)
                        if image_data:
                            images[filename] = image_data
                            self.logger.info(f"Successfully downloaded image: {filename}")
                        else:
                            self.logger.warning(f"Failed to download image: {filename}")

        except requests.exceptions.RequestException as e:
            self.logger.warning(f"Failed to fetch attachments: {str(e)}")
        except Exception as e:
            self.logger.warning(f"Error processing attachments: {str(e)}")

        return images

    def _download_attachment(self, download_url: str) -> Optional[str]:
        """Download attachment and return as base64 string with LLM-compatible format."""
        try:
            response = self.session.get(download_url, timeout=self.config.timeout)
            response.raise_for_status()

            # Get content type
            content_type = response.headers.get('content-type', 'image/png')
            
            # Use image converter to handle SVG conversion and optimization
            return self.image_converter.convert_to_base64_data_url(response.content, content_type)

        except requests.exceptions.RequestException as e:
            self.logger.warning(f"Failed to download attachment from {download_url}: {str(e)}")
            return None
        except Exception as e:
            self.logger.warning(f"Failed to process attachment from {download_url}: {str(e)}")
            return None

    def _get_image_extension(self, url: str) -> str:
        """Extract file extension from image URL."""
        path = urlparse(url).path
        if '.' in path:
            return path.split('.')[-1].lower()
        return 'png'

    def _extract_and_parse_drawio_diagrams(self, html_content: str) -> str:
        """Extract drawio diagrams from HTML and parse them to extract text content."""
        drawio_diagrams = []
        
        # Pattern 1: Drawio macro with embedded XML (most common)
        # <ac:structured-macro ac:name="drawio">...</ac:structured-macro>
        drawio_macro_pattern = r'<ac:structured-macro[^>]*ac:name="drawio"[^>]*>(.*?)</ac:structured-macro>'
        macro_matches = re.findall(drawio_macro_pattern, html_content, re.DOTALL | re.IGNORECASE)
        
        for i, macro_content in enumerate(macro_matches):
            # Look for ac:parameter with name="diagram-data" or similar
            diagram_data_pattern = r'<ac:parameter[^>]*ac:name="(?:diagram-data|diagramData|diagram)"[^>]*>(.*?)</ac:parameter>'
            data_matches = re.findall(diagram_data_pattern, macro_content, re.DOTALL | re.IGNORECASE)
            
            for diagram_xml in data_matches:
                parsed = self._parse_drawio_xml(diagram_xml)
                if parsed:
                    drawio_diagrams.append(f"### Drawio Diagram {i+1}\n\n{parsed}")
        
        # Pattern 2: Direct drawio XML in CDATA or encoded
        # Look for mxGraphModel or draw.io XML patterns
        xml_patterns = [
            r'<mxGraphModel[^>]*>(.*?)</mxGraphModel>',
            r'<mxfile[^>]*>(.*?)</mxfile>',
            r'<diagram[^>]*>(.*?)</diagram>',
        ]
        
        for pattern in xml_patterns:
            xml_matches = re.findall(pattern, html_content, re.DOTALL | re.IGNORECASE)
            for j, xml_content in enumerate(xml_matches):
                # Decode if it's URL encoded or base64
                try:
                    # Try to decode if it looks encoded
                    if '%' in xml_content:
                        xml_content = unescape(xml_content)
                    parsed = self._parse_drawio_xml(xml_content)
                    if parsed:
                        drawio_diagrams.append(f"### Drawio Diagram {len(drawio_diagrams)+1}\n\n{parsed}")
                except Exception as e:
                    self.logger.debug(f"Failed to parse drawio XML pattern: {str(e)}")
                    continue
        
        return "\n\n".join(drawio_diagrams) if drawio_diagrams else ""

    def _parse_drawio_xml(self, xml_content: str) -> Optional[str]:
        """Parse drawio XML and extract text labels, shapes, and connections."""
        try:
            # Decode HTML entities
            xml_content = unescape(xml_content)
            
            # Try to decode base64 if needed
            if not xml_content.strip().startswith('<'):
                try:
                    xml_content = base64.b64decode(xml_content).decode('utf-8')
                except:
                    # Try URL decoding
                    try:
                        xml_content = unquote(xml_content)
                    except:
                        pass
            
            # Parse XML
            try:
                root = ET.fromstring(xml_content)
            except ET.ParseError:
                # Sometimes the XML might be wrapped or have issues, try to extract mxGraphModel
                mxgraph_match = re.search(r'<mxGraphModel[^>]*>(.*?)</mxGraphModel>', xml_content, re.DOTALL)
                if mxgraph_match:
                    xml_content = f"<mxGraphModel>{mxgraph_match.group(1)}</mxGraphModel>"
                    root = ET.fromstring(xml_content)
                else:
                    raise
            
            # Extract information from the diagram
            elements = []
            connections = []
            
            # Find all mxCell elements (shapes, text, connections)
            for cell in root.iter():
                if cell.tag.endswith('cell') or 'cell' in cell.tag.lower():
                    # Get attributes
                    value = cell.get('value', '')
                    style = cell.get('style', '')
                    edge = cell.get('edge', '0')
                    source = cell.get('source', '')
                    target = cell.get('target', '')
                    id_attr = cell.get('id', '')
                    
                    # Extract text/labels
                    if value and value.strip():
                        # Clean up the value
                        value = value.strip()
                        # Remove HTML tags if present
                        value = re.sub(r'<[^>]+>', '', value)
                        if value:
                            elements.append(f"- {value}")
                    
                    # Extract connections
                    if edge == '1' and source and target:
                        source_label = self._get_cell_label(root, source)
                        target_label = self._get_cell_label(root, target)
                        if source_label and target_label:
                            connections.append(f"- {source_label} → {target_label}")
            
            # Build description
            description_parts = []
            
            if elements:
                description_parts.append("**Elements in diagram:**")
                description_parts.extend(elements[:50])  # Limit to first 50 elements
                if len(elements) > 50:
                    description_parts.append(f"... and {len(elements) - 50} more elements")
            
            if connections:
                description_parts.append("\n**Connections:**")
                description_parts.extend(connections[:50])  # Limit to first 50 connections
                if len(connections) > 50:
                    description_parts.append(f"... and {len(connections) - 50} more connections")
            
            if description_parts:
                return "\n".join(description_parts)
            
            return None
            
        except Exception as e:
            self.logger.debug(f"Failed to parse drawio XML: {str(e)}")
            return None

    def _get_cell_label(self, root: ET.Element, cell_id: str) -> Optional[str]:
        """Get the label/value of a cell by its ID."""
        try:
            for cell in root.iter():
                if cell.tag.endswith('cell') or 'cell' in cell.tag.lower():
                    if cell.get('id') == cell_id:
                        value = cell.get('value', '')
                        if value:
                            # Clean up the value
                            value = re.sub(r'<[^>]+>', '', value).strip()
                            return value if value else None
        except:
            pass
        return None
