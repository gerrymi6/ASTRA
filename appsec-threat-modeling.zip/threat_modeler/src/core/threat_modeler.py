"""
Main threat modeler class that orchestrates the threat modeling process.
"""

import re
from pathlib import Path
from datetime import datetime
import logging
from typing import Optional, Dict, Any

from .config import Config
from .confluence_client import ConfluenceClient, ConfluencePage
from .llm_client import LLMClient, LLMResponse

class ThreatModeler:
    """Main class for orchestrating threat modeling assessments."""

    def __init__(self, config: Config, logger: logging.Logger):
        self.config = config
        self.logger = logger

        # Initialize clients
        self.confluence_client = ConfluenceClient(config.confluence, logger)
        self.llm_client = LLMClient(
            provider=config.llm.provider,
            model=config.llm.model,
            api_key=config.llm.api_key,
            logger=logger,
            temperature=config.llm.temperature,
            base_url=config.llm.base_url,
            azure_deployment=config.llm.azure_deployment,
            azure_api_version=config.llm.azure_api_version,
            azure_auth_method=config.llm.azure_auth_method
        )

        # Validate LLM connection
        if not self.llm_client.validate_connection():
            raise RuntimeError("Failed to establish connection to LLM provider")

    def run_threat_modeling(self, confluence_url: str) -> Optional[str]:
        """Run the complete threat modeling process."""

        try:
            self.logger.info("Starting threat modeling process")

            # Step 1: Fetch Confluence documentation
            page = self.confluence_client.get_page_content(confluence_url)

            # Step 2: Generate initial threat model
            threat_model = self._generate_threat_model(page)

            # Step 3: Run gap analysis and iterative improvement
            if self.config.threat_modeling.gap_analysis_enabled:
                final_model = self._run_gap_analysis_loop(threat_model)
            else:
                final_model = threat_model

            # Step 4: Save final output
            output_path = self._save_output(final_model, page.title)

            # Step 5: Generate diagram if requested
            if self.config.threat_modeling.generate_diagram:
                diagram_path = self._generate_diagram(final_model, output_path.parent, page.title)
                self.logger.info(f"DFDv3 diagram generated: {diagram_path}")

            self.logger.info(f"Threat modeling process completed successfully")
            return str(output_path)

        except Exception as e:
            self.logger.error(f"Threat modeling process failed: {str(e)}")
            raise

    def _generate_diagram(self, threat_model: str, output_dir: Path, page_title: str) -> str:
        """Generate DFDv3 diagram in drawio format from threat model with iterative improvement."""
        self.logger.info("Generating DFDv3 diagram...")

        try:
            # Start with initial diagram generation
            current_diagram_spec = self._generate_initial_diagram(threat_model)

            # Run diagram gap analysis and improvement loop (5 iterations)
            max_diagram_iterations = 5
            for iteration in range(max_diagram_iterations):
                self.logger.info(f"Diagram analysis iteration {iteration + 1}/{max_diagram_iterations}")

                # Analyze gaps in current diagram
                gap_analysis = self._analyze_diagram_gaps(current_diagram_spec, threat_model)

                # Check if diagram is complete
                if self._is_diagram_complete(gap_analysis):
                    self.logger.info("Diagram is complete - stopping iterations")
                    break

                # Generate improved diagram specification
                current_diagram_spec = self._improve_diagram(current_diagram_spec, gap_analysis, threat_model)

            # Generate final drawio XML from the improved specification
            drawio_xml = self._create_drawio_xml(current_diagram_spec, page_title)

            # Save the diagram file
            safe_title = re.sub(r'[^\w\-_\.]', '_', page_title)
            diagram_filename = f"threat_model_diagram_{safe_title}.drawio"
            diagram_path = output_dir / diagram_filename

            with open(diagram_path, 'w', encoding='utf-8') as f:
                f.write(drawio_xml)

            self.logger.info(f"DFDv3 diagram saved to: {diagram_path}")
            return str(diagram_path)

        except Exception as e:
            self.logger.error(f"Failed to generate diagram: {str(e)}")
            raise

    def _generate_initial_diagram(self, threat_model: str) -> str:
        """Generate initial diagram specification using LLM."""
        diagram_prompt = f"""You are a threat modeling expert. Based on the following threat model, generate a comprehensive Data Flow Diagram (DFDv3) specification that can be used to create a visual diagram.

THREAT MODEL:
{threat_model}

Please provide a detailed DFDv3 specification that includes:

1. **External Entities** (users, external systems, APIs, third-party services)
2. **Processes** (main system components, applications, services, functions)
3. **Data Stores** (databases, file systems, external storage, caches)
4. **Trust Boundaries** (security boundaries, network segments, access controls)
5. **Data Flows** (all connections between entities, processes, and data stores)

Format your response as a structured specification that includes:
- Element ID and Name
- Type (External Entity, Process, Data Store, Trust Boundary, Data Flow)
- Description (security implications and functionality)
- Position (x, y coordinates for layout)
- Connections (what it connects to and data flow details)
- Security Controls (any security measures applied)

Make it comprehensive and ensure ALL security-relevant components from the threat model are represented."""

        try:
            response = self.llm_client.generate_response(diagram_prompt)
            return response.content
        except Exception as e:
            self.logger.error(f"Failed to generate initial diagram: {str(e)}")
            raise

    def _analyze_diagram_gaps(self, diagram_spec: str, threat_model: str) -> str:
        """Analyze gaps in the diagram specification."""
        gap_prompt = f"""You are a senior security architect reviewing a Data Flow Diagram specification for completeness and accuracy.

Review the following diagram specification against the original threat model:

THREAT MODEL:
{threat_model}

DIAGRAM SPECIFICATION:
{diagram_spec}

Please analyze the diagram and identify any gaps, missing elements, or areas that need improvement:

1. **Missing Components:**
   - Are all external entities from the threat model represented?
   - Are all processes and system components included?
   - Are all data stores identified?
   - Are trust boundaries clearly defined?

2. **Data Flow Completeness:**
   - Are all data flows between components represented?
   - Are trust boundaries properly shown?
   - Are security controls visualized?

3. **Security Aspects:**
   - Are security-critical components highlighted?
   - Are trust boundaries clearly marked?
   - Are sensitive data flows identified?

4. **Layout and Clarity:**
   - Is the diagram logically organized?
   - Are connections clear and labeled?
   - Are there sufficient details for security analysis?

5. **Threat Model Alignment:**
   - Does the diagram accurately represent the threat model?
   - Are all assets and entry points visualized?
   - Are security controls properly represented?

Rate the diagram completeness on a scale of 1-10 and provide specific recommendations for improvement.

If the diagram adequately covers all critical aspects and requires no significant improvements, respond with "COMPLETE" followed by a brief justification.

Otherwise, provide specific, actionable recommendations organized by priority (High/Medium/Low) with clear explanations of what's missing."""

        try:
            response = self.llm_client.generate_response(gap_prompt)
            return response.content
        except Exception as e:
            self.logger.error(f"Failed to analyze diagram gaps: {str(e)}")
            raise

    def _is_diagram_complete(self, gap_analysis: str) -> bool:
        """Determine if the diagram is complete based on gap analysis."""
        # Simple heuristic: check if analysis contains "COMPLETE"
        if "COMPLETE" in gap_analysis.upper():
            return True

        # Check for common completion indicators
        completion_indicators = [
            "no gaps found",
            "diagram is complete",
            "no further improvements needed",
            "comprehensive coverage",
            "all aspects covered",
            "assessment score.*10/10",
            "assessment score.*9/10",
            "assessment score.*8/10"
        ]

        gap_analysis_lower = gap_analysis.lower()
        for indicator in completion_indicators:
            if indicator in gap_analysis_lower:
                return True

        return False

    def _improve_diagram(self, current_diagram: str, gap_analysis: str, threat_model: str) -> str:
        """Generate improved diagram specification based on gap analysis."""
        improvement_prompt = f"""You are a threat modeling expert tasked with improving a Data Flow Diagram specification based on gap analysis feedback.

ORIGINAL THREAT MODEL:
{threat_model}

CURRENT DIAGRAM SPECIFICATION:
{current_diagram}

GAP ANALYSIS FEEDBACK:
{gap_analysis}

Please provide an improved diagram specification that addresses all the identified gaps and incorporates the suggested improvements. Ensure the diagram includes:

1. **All Missing Components** identified in the gap analysis
2. **Complete Data Flows** with proper security annotations
3. **Trust Boundaries** clearly marked and explained
4. **Security Controls** visualized where applicable
5. **Logical Layout** that's easy to understand

Maintain the same structured format but enhance the content with the missing elements and improved security coverage."""

        try:
            response = self.llm_client.generate_response(improvement_prompt)
            return response.content
        except Exception as e:
            self.logger.error(f"Failed to improve diagram: {str(e)}")
            raise

    def _create_drawio_xml(self, diagram_spec: str, page_title: str) -> str:
        """Create drawio XML format from diagram specification."""
        # This is a basic drawio XML template with placeholders for diagram elements
        # In a real implementation, you would parse the diagram_spec and create proper XML

        drawio_template = f"""<?xml version="1.0" encoding="UTF-8"?>
<mxfile host="app.diagrams.net" modified="2024-01-01T00:00:00.000Z" agent="5.0 (Windows)" etag="hash" version="24.7.17" type="device">
  <diagram name="Threat Model Diagram" id="diagram-id">
    <mxGraphModel dx="1000" dy="800" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="827" pageHeight="1169" math="0" shadow="0">
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
        
        <!-- Page Title -->
        <mxCell id="page-title" value="{page_title} - Threat Model DFDv3" style="text;fontSize=16;fontStyle=1;" parent="1" vertex="1">
          <mxGeometry x="50" y="20" width="400" height="30" as="geometry"/>
        </mxCell>
        
        <!-- Trust Boundary -->
        <mxCell id="trust-boundary" value="Trust Boundary" style="shape=ellipse;strokeColor=#FF0000;fillColor=#FFFFFF;strokeWidth=3;" parent="1" vertex="1">
          <mxGeometry x="100" y="100" width="600" height="400" as="geometry"/>
        </mxCell>
        
        <!-- External Entity -->
        <mxCell id="external-entity" value="External User/System" style="shape=ellipse;fillColor=#E6E6E6;strokeColor=#000000;" parent="1" vertex="1">
          <mxGeometry x="50" y="250" width="100" height="60" as="geometry"/>
        </mxCell>
        
        <!-- Process -->
        <mxCell id="process" value="Main Application" style="shape=rectangle;fillColor=#FFFFFF;strokeColor=#000000;" parent="1" vertex="1">
          <mxGeometry x="250" y="250" width="120" height="80" as="geometry"/>
        </mxCell>
        
        <!-- Data Store -->
        <mxCell id="data-store" value="Database" style="shape=parallelogram;fillColor=#E6E6E6;strokeColor=#000000;" parent="1" vertex="1">
          <mxGeometry x="450" y="250" width="100" height="60" as="geometry"/>
        </mxCell>
        
        <!-- Data Flow -->
        <mxCell id="data-flow-1" value="Data Flow" style="endArrow=classic;html=1;fontColor=#000000;" parent="1" source="external-entity" target="process" edge="1">
          <mxGeometry width="50" height="50" relative="1" as="geometry">
            <mxPoint x="0" y="0" as="sourcePoint"/>
            <mxPoint x="0" y="0" as="targetPoint"/>
          </mxGeometry>
        </mxCell>
        
        <!-- Legend -->
        <mxCell id="legend-title" value="Legend" style="text;fontSize=14;fontStyle=1;" parent="1" vertex="1">
          <mxGeometry x="50" y="550" width="100" height="20" as="geometry"/>
        </mxCell>
        
        <mxCell id="legend-external" value="External Entity" style="shape=ellipse;fillColor=#E6E6E6;strokeColor=#000000;" parent="1" vertex="1">
          <mxGeometry x="50" y="580" width="80" height="30" as="geometry"/>
        </mxCell>
        
        <mxCell id="legend-process" value="Process" style="shape=rectangle;fillColor=#FFFFFF;strokeColor=#000000;" parent="1" vertex="1">
          <mxGeometry x="150" y="580" width="80" height="30" as="geometry"/>
        </mxCell>
        
        <mxCell id="legend-datastore" value="Data Store" style="shape=parallelogram;fillColor=#E6E6E6;strokeColor=#000000;" parent="1" vertex="1">
          <mxGeometry x="250" y="580" width="80" height="30" as="geometry"/>
        </mxCell>
        
        <mxCell id="legend-boundary" value="Trust Boundary" style="shape=ellipse;strokeColor=#FF0000;fillColor=#FFFFFF;strokeWidth=3;" parent="1" vertex="1">
          <mxGeometry x="350" y="580" width="80" height="30" as="geometry"/>
        </mxCell>
        
        <!-- Notes -->
        <mxCell id="notes" value="Generated DFDv3 Diagram&#10;Based on threat model analysis&#10;{diagram_spec[:200]}..." style="text;fontSize=10;" parent="1" vertex="1">
          <mxGeometry x="50" y="650" width="400" height="100" as="geometry"/>
        </mxCell>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>"""

        return drawio_template

    def _generate_threat_model(self, page: ConfluencePage) -> str:
        """Generate initial threat model using LLM."""

        self.logger.info("Generating initial threat model")

        # Load prompt template
        prompt_template = self.config.load_prompt("threat_model_generation")

        # Prepare the prompt with documentation
        prompt = prompt_template.replace("{documentation}", page.content)

        # Generate threat model
        response = self.llm_client.generate_response(
            prompt=prompt,
            images=page.images if self.config.output.include_images else None
        )

        self.logger.info("Initial threat model generated successfully")
        return response.content

    def _run_gap_analysis_loop(self, initial_model: str) -> str:
        """Run iterative gap analysis and improvement loop."""

        self.logger.info("Starting gap analysis loop")
        current_model = initial_model
        max_iterations = self.config.threat_modeling.max_iterations

        for iteration in range(max_iterations):
            self.logger.info(f"Gap analysis iteration {iteration + 1}/{max_iterations}")

            # Run gap analysis
            gap_analysis = self._analyze_gaps(current_model)

            # Check if model is complete
            if self._is_model_complete(gap_analysis):
                self.logger.info("Threat model is complete - stopping iterations")
                break

            # Generate improved model based on gap analysis
            current_model = self._improve_model(current_model, gap_analysis)

        self.logger.info("Gap analysis loop completed")
        return current_model

    def _analyze_gaps(self, threat_model: str) -> str:
        """Analyze gaps in the threat model using LLM."""

        # Load gap analysis prompt
        prompt_template = self.config.load_prompt("gap_analysis")

        # Prepare prompt
        prompt = prompt_template.replace("{threat_model}", threat_model)

        # Generate gap analysis
        response = self.llm_client.generate_response(prompt)

        return response.content

    def _is_model_complete(self, gap_analysis: str) -> bool:
        """Determine if the threat model is complete based on gap analysis."""

        # Simple heuristic: check if analysis contains "COMPLETE"
        if "COMPLETE" in gap_analysis.upper():
            return True

        # Check for common completion indicators
        completion_indicators = [
            "no gaps found",
            "threat model is complete",
            "no further improvements needed",
            "assessment score.*10/10",
            "assessment score.*5/5"
        ]

        gap_analysis_lower = gap_analysis.lower()
        for indicator in completion_indicators:
            if indicator in gap_analysis_lower:
                return True

        return False

    def _improve_model(self, current_model: str, gap_analysis: str) -> str:
        """Generate improved threat model based on gap analysis."""

        improvement_prompt = f"""You are a senior security architect tasked with improving a threat model based on gap analysis feedback.

Current Threat Model:
{current_model}

Gap Analysis Feedback:
{gap_analysis}

Please provide an improved version of the threat model that addresses all the identified gaps and incorporates the suggested improvements. Maintain the same overall structure and format while enhancing the content with the missing elements."""

        response = self.llm_client.generate_response(improvement_prompt)
        return response.content

    def _save_output(self, threat_model: str, page_title: str) -> Path:
        """Save the final threat model to output directory."""

        # Create output directory if it doesn't exist
        output_dir = Path(self.config.output.directory)
        if self.config.output.create_timestamped_dirs:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_dir = output_dir / f"threat_model_{timestamp}"

        output_dir.mkdir(parents=True, exist_ok=True)

        # Generate filename from page title
        safe_title = re.sub(r'[^\w\-_\.]', '_', page_title)
        filename = f"threat_model_{safe_title}.md"
        output_path = output_dir / filename

        # Save the threat model
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(f"# Threat Model: {page_title}\n\n")
            f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("---\n\n")
            f.write(threat_model)

        self.logger.info(f"Threat model saved to: {output_path}")
        return output_path
