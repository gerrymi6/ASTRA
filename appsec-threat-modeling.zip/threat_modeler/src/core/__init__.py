"""Core modules for Threat Modeler."""
