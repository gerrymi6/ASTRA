"""
Image conversion utilities for handling different image formats.
"""

import base64
import io
import logging
from typing import Optional, Tuple

# Optional dependencies for image processing
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import cairosvg
    CAIROSVG_AVAILABLE = True
except (ImportError, OSError) as e:
    # ImportError: cairosvg not installed
    # OSError: Cairo graphics library not installed on system
    CAIROSVG_AVAILABLE = False


class ImageConverter:
    """Utility class for converting images to formats supported by LLMs."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger(__name__)
        
        # Check for required dependencies
        if not PIL_AVAILABLE:
            self.logger.warning("PIL (Pillow) not available - image optimization disabled")
        if not CAIROSVG_AVAILABLE:
            self.logger.warning("cairosvg not available - SVG conversion disabled")
    
    def convert_svg_to_png(self, svg_content: bytes, width: int = 1024, height: int = 768) -> Optional[bytes]:
        """
        Convert SVG content to PNG format.
        
        Args:
            svg_content: Raw SVG bytes
            width: Target width for PNG conversion
            height: Target height for PNG conversion
            
        Returns:
            PNG bytes or None if conversion fails
        """
        if not CAIROSVG_AVAILABLE:
            self.logger.error("cairosvg not available - cannot convert SVG to PNG")
            return None
            
        try:
            # Convert SVG to PNG using cairosvg
            png_bytes = cairosvg.svg2png(
                bytestring=svg_content,
                output_width=width,
                output_height=height
            )
            
            self.logger.debug(f"Successfully converted SVG to PNG ({width}x{height})")
            return png_bytes
            
        except Exception as e:
            self.logger.warning(f"Failed to convert SVG to PNG: {str(e)}")
            return None
    
    def optimize_image_for_llm(self, image_content: bytes, content_type: str, 
                              max_size_mb: float = 20.0, max_dimension: int = 2048) -> Tuple[bytes, str]:
        """
        Optimize image for LLM processing by resizing and compressing if necessary.
        
        Args:
            image_content: Raw image bytes
            content_type: Original content type (e.g., 'image/png')
            max_size_mb: Maximum file size in MB
            max_dimension: Maximum width or height in pixels
            
        Returns:
            Tuple of (optimized_bytes, content_type)
        """
        try:
            # Check if it's SVG and needs conversion
            if 'svg' in content_type.lower():
                self.logger.info("Converting SVG image to PNG for LLM compatibility")
                png_bytes = self.convert_svg_to_png(image_content)
                if png_bytes:
                    image_content = png_bytes
                    content_type = 'image/png'
                else:
                    self.logger.error("SVG conversion failed, skipping image")
                    raise ValueError("SVG conversion failed")
            
            # Skip optimization if PIL is not available
            if not PIL_AVAILABLE:
                self.logger.warning("PIL not available - returning original image without optimization")
                return image_content, content_type
            
            # Open image with Pillow for optimization
            with Image.open(io.BytesIO(image_content)) as img:
                # Convert to RGB if necessary (for JPEG compatibility)
                if img.mode in ('RGBA', 'LA', 'P'):
                    # Create a white background for transparency
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = background
                
                # Resize if too large
                if max(img.size) > max_dimension:
                    ratio = max_dimension / max(img.size)
                    new_size = (int(img.width * ratio), int(img.height * ratio))
                    img = img.resize(new_size, Image.Resampling.LANCZOS)
                    self.logger.debug(f"Resized image to {new_size}")
                
                # Save optimized image
                output_buffer = io.BytesIO()
                
                # Choose format based on content type and optimization needs
                if content_type.startswith('image/jpeg') or content_type.startswith('image/jpg'):
                    img.save(output_buffer, format='JPEG', quality=85, optimize=True)
                    final_content_type = 'image/jpeg'
                else:
                    # Default to PNG for better quality
                    img.save(output_buffer, format='PNG', optimize=True)
                    final_content_type = 'image/png'
                
                optimized_bytes = output_buffer.getvalue()
                
                # Check file size
                size_mb = len(optimized_bytes) / (1024 * 1024)
                if size_mb > max_size_mb:
                    self.logger.warning(f"Image size ({size_mb:.1f}MB) exceeds limit ({max_size_mb}MB)")
                    # Try JPEG with lower quality if it was PNG
                    if final_content_type == 'image/png':
                        output_buffer = io.BytesIO()
                        img.save(output_buffer, format='JPEG', quality=60, optimize=True)
                        optimized_bytes = output_buffer.getvalue()
                        final_content_type = 'image/jpeg'
                        size_mb = len(optimized_bytes) / (1024 * 1024)
                        self.logger.info(f"Converted to JPEG, new size: {size_mb:.1f}MB")
                
                self.logger.debug(f"Optimized image: {size_mb:.1f}MB, {img.size}, {final_content_type}")
                return optimized_bytes, final_content_type
                
        except Exception as e:
            self.logger.warning(f"Image optimization failed: {str(e)}")
            # Return original if optimization fails (unless it's SVG)
            if 'svg' in content_type.lower():
                raise
            return image_content, content_type
    
    def convert_to_base64_data_url(self, image_content: bytes, content_type: str) -> str:
        """
        Convert image bytes to base64 data URL format expected by OpenAI.
        
        Args:
            image_content: Raw image bytes
            content_type: MIME content type
            
        Returns:
            Base64 data URL string
        """
        try:
            # Check if it's SVG and we can't convert it
            if 'svg' in content_type.lower() and not CAIROSVG_AVAILABLE:
                self.logger.warning("SVG image detected but cairosvg not available - skipping image")
                self.logger.info("To enable SVG conversion, install Cairo system library and run: pip install cairosvg")
                raise ValueError("SVG conversion not available")
            
            # Optimize image for LLM
            optimized_content, optimized_type = self.optimize_image_for_llm(image_content, content_type)
            
            # Encode to base64
            base64_data = base64.b64encode(optimized_content).decode('utf-8')
            
            # Create data URL
            data_url = f"data:{optimized_type};base64,{base64_data}"
            
            self.logger.debug(f"Created base64 data URL for {optimized_type}")
            return data_url
            
        except Exception as e:
            self.logger.error(f"Failed to convert image to base64 data URL: {str(e)}")
            raise
